# coding:UTF-8
"""
    byte数组工具类
"""


class ByteArrayConvert:
    pass
